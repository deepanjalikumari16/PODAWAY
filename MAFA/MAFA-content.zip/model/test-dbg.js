(function(){ 
    var foo = 3; 
    alert(foo); 
})(); 
